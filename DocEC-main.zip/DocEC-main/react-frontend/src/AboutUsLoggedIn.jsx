import React from "react";
import "./AboutUsLoggedIn.css";
import clinic1 from "./assets/clinic.jpg";
import clinic2 from "./assets/clinicser.jpg";
import exam from "./assets/abouteye.png";

const AboutUsLoggedIn = () => {
  return (
    <div className="page-wrapper">
      <div className="aboutus-container">
        {/* HEADER SECTION */}
        <section className="aboutus-header">
          <div className="aboutus-text">
            <h1>About Us</h1>
            <h2>Who We Are</h2>
            <p>
              Doctor EC Optical Clinic is dedicated to providing excellent and
              compassionate eye care for patients of all ages. We offer
              comprehensive eye examinations, accurate vision testing, and a wide
              selection of quality eyewear to meet every individual’s needs.
              Guided by a passion for eye health and personalized service, our
              clinic strives to help every patient achieve clear vision and
              lasting comfort.
            </p>
          </div>

          <div className="aboutus-image">
            <img src={exam} alt="Eye Examination" />
          </div>
        </section>

        {/* EXPERIENCE SECTION */}
        <section className="experience-section">
          <h2>Experience Personalized Care at our Clinic</h2>
          <p>
            Experience personalized care at Doctor EC Optical Clinic, where your
            vision and comfort are our top priorities.
          </p>

          <div className="branch-grid">
            {/* MAIN BRANCH */}
            <div className="branch-card">
              <img src={clinic1} alt="Doctor EC Optical Clinic Main Branch" />
              <h3>Doctor EC Optical Clinic (Main Branch)</h3>
              <p>
                <strong>Address:</strong> 2nd Floor, G.F. Building, Main Street,
                San Fernando City, Pampanga
              </p>
              <p>
                <strong>Hours:</strong> Monday–Saturday | 9:00 AM – 6:00 PM
              </p>
              <button className="book-btn">Book an Appointment</button>
            </div>

            {/* DOWNTOWN BRANCH */}
            <div className="branch-card">
              <img src={clinic2} alt="Doctor EC Optical Clinic Downtown Branch" />
              <h3>Doctor EC Optical Clinic (Downtown Branch)</h3>
              <p>
                <strong>Address:</strong> Ground Floor, M.A. Complex, Downtown
                Area, Angeles City, Pampanga
              </p>
              <p>
                <strong>Hours:</strong> Monday–Saturday | 10:00 AM – 7:00 PM
              </p>
              <button className="book-btn">Book an Appointment</button>
            </div>
          </div>
        </section>
      </div>

      {/* ✅ FOOTER WITH WORKING SOCIAL ICONS */}
      <footer className="aboutus-footer">
        <div className="footer-icons">
          <a
            href="https://www.facebook.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Facebook"
          >
            <i className="fab fa-facebook-f"></i>
          </a>

          <a
            href="https://www.instagram.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Instagram"
          >
            <i className="fab fa-instagram"></i>
          </a>

          <a
            href="https://x.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Twitter / X"
          >
            <i className="fab fa-x-twitter"></i>
          </a>

          <a
            href="https://www.tiktok.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="TikTok"
          >
            <i className="fab fa-tiktok"></i>
          </a>
        </div>

        <p>© 2025 Doctor EC Optical Clinic. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default AboutUsLoggedIn;
