import React, { useState } from "react";
import "./AppointmentModal.css";

const AppointmentModal = ({ open, onClose, onSubmit }) => {
  const [form, setForm] = useState({
    date: "",
    time: "",
    reason: "",
    notes: "",
  });

  if (!open) return null;

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(form);
  };

  return (
    <div className="apm-overlay" onClick={onClose}>
      <div className="apm-box" onClick={(e) => e.stopPropagation()}>
        <h3>Book Your Appointment</h3>

        <form className="apm-form" onSubmit={handleSubmit}>
          <div className="apm-row">
            <label>
              Date:
              <input
                type="date"
                name="date"
                value={form.date}
                onChange={handleChange}
                required
              />
            </label>
            <label>
              Time:
              <input
                type="time"
                name="time"
                value={form.time}
                onChange={handleChange}
                required
              />
            </label>
          </div>

          <label>
            Reason for Visit:
            <input
              type="text"
              name="reason"
              placeholder="Reason for Visit"
              value={form.reason}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            Notes / Symptoms:
            <textarea
              name="notes"
              placeholder="Notes / Symptoms"
              value={form.notes}
              onChange={handleChange}
            />
          </label>

          <div className="apm-actions">
            <button type="submit" className="apm-book">
              Book Now
            </button>
            <button type="button" className="apm-cancel" onClick={onClose}>
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AppointmentModal;
