// App.jsx - Updated imports and routes
import "@fortawesome/fontawesome-free/css/all.min.css";
import React, { useState, useRef, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, Link, Navigate } from "react-router-dom";

import Home from "./Home";
import Services from "./Services";
import Products from "./Products";
import AboutUs from "./AboutUs";
import AdminDashboard from "./AdminDashboard"; // 🔸 NEW: Import Admin Dashboard

import HomeLoggedIn from "./HomeLoggedIn";
import ServicesLoggedIn from "./ServicesLoggedIn";
import ProductsLoggedIn from "./ProductsLoggedIn";
import AboutUsLoggedIn from "./AboutUsLoggedIn";

import "./App.css";
import logo from "./assets/logo.jpg";
import iconsign from "./assets/iconsign.png";
import SignInModal from "./SignInModal";

/* 🔸 Add a small component for the dropdown profile card */
function UserProfileCard({ onSignOut, isAdmin = true }) { // 🔸 Added isAdmin prop
  const handleCalendarClick = (e) => {
    e.stopPropagation();
    alert("Open calendar or date picker here");
  };

  const handleAdminDashboardClick = (e) => {
    e.stopPropagation();
    // Navigate to admin dashboard
    window.location.href = '/admin';
  };

  return (
    <div className="profile-card" onClick={(e) => e.stopPropagation()}>
      <div className="profile-header">
        <div className="profile-circle">JD</div>
        <button className="calendar-btn" onClick={handleCalendarClick}>
          <i className="fa fa-calendar"></i>
        </button>
      </div>
      <h3>Jemiah Dapis</h3>
      <p>26 years old</p>
      
      {/* 🔸 Conditionally show admin badge */}
      {isAdmin && (
        <div className="role-badge">
          <i className="fa fa-shield"></i>
          Administrator
        </div>
      )}
      
      <hr />
      <p><strong>Gender:</strong> Male</p>
      <p><strong>Email:</strong> jemiahdel@gmail.com</p>
      <p><strong>Phone:</strong> 0912 345 6789</p>
      
      <div className="profile-actions">
        <button>
          <i className="fa fa-edit"></i>
          Edit Profile
        </button>
        
        {/* 🔸 Conditionally show admin dashboard button */}
        {isAdmin && (
          <button className="admin-btn" onClick={handleAdminDashboardClick}>
            <i className="fa fa-tachometer-alt"></i>
            Admin Dashboard
          </button>
        )}
        
        <button onClick={onSignOut}>
          <i className="fa fa-sign-out-alt"></i>
          Sign Out
        </button>
      </div>
    </div>
  );
}

function App() {
  const [isSignedIn, setIsSignedIn] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [userRole, setUserRole] = useState('user'); // 🔸 NEW: Track user role

  // 🔸 NEW state for showing the user info popup
  const [showProfile, setShowProfile] = useState(false);
  const profileRef = useRef();

  // 🔸 NEW state for sticky navbar
  const [isSticky, setIsSticky] = useState(false);

  const handleSignInClick = () => setShowModal(true);
  const handleSignInSuccess = (role = 'user') => { // 🔸 UPDATED: Accept role parameter
    setIsSignedIn(true);
    setUserRole(role);
    setShowModal(false);
  };
  const handleSignOut = () => {
    setIsSignedIn(false);
    setUserRole('user');
    setShowProfile(false);
  };

  // 🔸 Close the profile card if clicked outside
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (profileRef.current && !profileRef.current.contains(e.target)) {
        setShowProfile(false);
      }
    };
    document.addEventListener("click", handleClickOutside);
    return () => document.removeEventListener("click", handleClickOutside);
  }, []);

  // 🔸 NEW: Sticky navbar effect
  useEffect(() => {
    const handleScroll = () => {
      const offset = window.scrollY;
      if (offset > 50) {
        setIsSticky(true);
        document.body.classList.add('sticky-nav');
      } else {
        setIsSticky(false);
        document.body.classList.remove('sticky-nav');
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <Router>
      <div className="App">
        {isSignedIn ? (
          <header className={`navbar ${isSticky ? 'sticky' : ''}`}>
            <div className="logo">
              <img src={logo} alt="Clinic Logo" className="logo-img" />
              <span>Doctor EC Optical Clinic</span>
            </div>

            <nav>
              <ul>
                <li><Link to="/">HOME</Link></li>
                <li><Link to="/services">SERVICES</Link></li>
                <li><Link to="/products">PRODUCTS</Link></li>
                <li><Link to="/about">ABOUT US</Link></li>
                {/* 🔸 NEW: Admin link in navbar for easy access */}
                {userRole === 'admin' && (
                  <li>
                    <Link to="/admin" className="admin-nav-link">
                      <i className="fa fa-tachometer-alt"></i>
                      ADMIN
                    </Link>
                  </li>
                )}
              </ul>
            </nav>

            <div className="nav-buttons" ref={profileRef}>
              <button className="book-btn">Book Now</button>

              {/* 🔸 Changed behavior: toggle profile instead of sign out */}
              <button
                className="icon-image-btn"
                title="User Profile"
                onClick={(e) => {
                  e.stopPropagation();
                  setShowProfile((prev) => !prev);
                }}
              >
                <img src={iconsign} alt="User Icon" className="user-icon" />
              </button>

              <input type="text" placeholder="Search..." />

              {/* 🔸 Profile popup */}
              {showProfile && (
                <UserProfileCard 
                  onSignOut={handleSignOut} 
                  isAdmin={userRole === 'admin'} // 🔸 Pass admin status
                />
              )}
            </div>
          </header>
        ) : (
          <header className={`navbar ${isSticky ? 'sticky' : ''}`}>
            <div className="logo">
              <img src={logo} alt="Clinic Logo" className="logo-img" />
              <span>Doctor EC Optical Clinic</span>
            </div>

            <nav>
              <ul>
                <li><Link to="/">HOME</Link></li>
                <li><Link to="/services">SERVICES</Link></li>
                <li><Link to="/products">PRODUCTS</Link></li>
                <li><Link to="/about">ABOUT US</Link></li>
              </ul>
            </nav>

            <div className="nav-buttons">
              <button className="book-btn">Book Now</button>
              <button className="sign-btn" onClick={handleSignInClick}>
                Sign In
              </button>
              <input type="text" placeholder="Search..." />
            </div>
          </header>
        )}

        {/* Routes */}
        <Routes>
          <Route path="/" element={isSignedIn ? <HomeLoggedIn /> : <Home />} />
          <Route
            path="/services"
            element={isSignedIn ? <ServicesLoggedIn /> : <Services />}
          />
          <Route
            path="/products"
            element={isSignedIn ? <ProductsLoggedIn /> : <Products />}
          />
          <Route
            path="/about"
            element={isSignedIn ? <AboutUsLoggedIn /> : <AboutUs />}
          />
          {/* 🔸 NEW: Admin Dashboard Route */}
          <Route
            path="/admin"
            element={
              isSignedIn && userRole === 'admin' ? (
                <AdminDashboard />
              ) : (
                <Navigate to="/" replace />
              )
            }
          />
        </Routes>

        {showModal && (
          <SignInModal
            onClose={() => setShowModal(false)}
            onSignInSuccess={() => handleSignInSuccess('admin')} // 🔸 For demo, set as admin
          />
        )}
      </div>
    </Router>
  );
}

export default App;