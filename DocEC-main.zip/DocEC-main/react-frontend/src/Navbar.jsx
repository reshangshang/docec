import React, { useState, useRef, useEffect } from "react";
import UserProfile from "./UserProfile";
import { FaUserCircle } from "react-icons/fa";

export default function Navbar({ user, signOut }) {
  const [open, setOpen] = useState(false);
  const toggleRef = useRef(null);

  // Click outside to close
  useEffect(() => {
    function handleClickOutside(e) {
      if (toggleRef.current && !toggleRef.current.contains(e.target)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <nav className="navbar">
      <div className="navbar-logo">My App</div>

      <div ref={toggleRef} style={{ position: "relative" }}>
        <button
          className="icon-button"
          onClick={() => setOpen((prev) => !prev)}
        >
          <FaUserCircle size={32} />
        </button>

        {open && (
          <UserProfile
            user={user}
            onClose={() => setOpen(false)}
            onExplicitSignOut={signOut}
          />
        )}
      </div>
    </nav>
  );
}
