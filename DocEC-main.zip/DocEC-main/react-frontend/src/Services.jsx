import React from "react";
import "./Services.css";

import onlineBooking from "./assets/online-booking.jpg";
import aiChatbot from "./assets/ai-chatbot.jpg";
import visionTest from "./assets/eye-exam.jpg";
import productCatalog from "./assets/product-catalog.jpg";
import accountAccess from "./assets/account-access.jpg";
import notifications from "./assets/notifications.jpg";
import recommendations from "./assets/recommendations.jpg";

function Services() {
  return (
    <div className="services-container">
      {/* HERO SECTION */}
      <section className="services-hero">
        <div className="hero-background">
          <div className="soft-shape shape-1"></div>
          <div className="soft-shape shape-2"></div>
          <div className="soft-shape shape-3"></div>
        </div>
        <div className="hero-content">
          <div className="hero-text">
            <h1>Digital Eye Care Experience</h1>
            <p className="hero-subtitle">
              Seamless digital services that bring premium optical care to your fingertips. 
              From AI-powered recommendations to effortless online booking.
            </p>
            <div className="hero-features">
              <div className="feature-item">
                <span className="feature-icon">🤖</span>
                <span>AI-Powered Assistance</span>
              </div>
              <div className="feature-item">
                <span className="feature-icon">📱</span>
                <span>Digital Convenience</span>
              </div>
              <div className="feature-item">
                <span className="feature-icon">⚡</span>
                <span>Instant Access</span>
              </div>
            </div>
          </div>
          <div className="hero-image">
            <img src={onlineBooking} alt="Digital eye care platform" />
            <div className="image-overlay"></div>
          </div>
        </div>
      </section>

      {/* DIGITAL SERVICES GRID */}
      <section className="digital-services">
        <div className="section-header">
          <h2>Our Digital Services</h2>
          <p>Modern solutions for modern eye care needs</p>
        </div>

        <div className="services-grid">
          {/* Online Account & Access */}
          <div className="service-card">
            <div className="card-header">
              <div className="card-icon">👤</div>
              <h3>Online Account & Access</h3>
            </div>
            <img src={accountAccess} alt="Online account management" />
            <div className="card-content">
              <p>Secure personal account management for all your eye care needs</p>
              <ul className="feature-list">
                <li>Create personal account</li>
                <li>Secure login & logout</li>
                <li>Password recovery</li>
                <li>Email/SMS verification</li>
              </ul>
              <button className="service-btn">Get Started</button>
            </div>
          </div>

          {/* Online Check-Up Booking */}
          <div className="service-card">
            <div className="card-header">
              <div className="card-icon">📅</div>
              <h3>Online Check-Up Booking</h3>
            </div>
            <img src={onlineBooking} alt="Online appointment booking" />
            <div className="card-content">
              <p>Effortless appointment scheduling with full control</p>
              <ul className="feature-list">
                <li>Book eye check-ups online</li>
                <li>Choose preferred date & time</li>
                <li>Reschedule appointments</li>
                <li>Cancel appointments</li>
                <li>Booking confirmations</li>
                <li>Automated reminders</li>
              </ul>
              <button className="service-btn">Book Now</button>
            </div>
          </div>

          {/* Online Product Browsing */}
          <div className="service-card">
            <div className="card-header">
              <div className="card-icon">🛍️</div>
              <h3>Product Catalog</h3>
            </div>
            <img src={productCatalog} alt="Optical products catalog" />
            <div className="card-content">
              <p>Comprehensive browsing of premium optical products</p>
              <ul className="feature-list">
                <li>Browse eyeglasses & frames</li>
                <li>View lenses & accessories</li>
                <li>High-quality product images</li>
                <li>Detailed specifications</li>
                <li>Transparent pricing</li>
                <li>Search by name/category</li>
              </ul>
              <button className="service-btn">Browse Catalog</button>
            </div>
          </div>

          {/* AI Recommendations */}
          <div className="service-card">
            <div className="card-header">
              <div className="card-icon">🎯</div>
              <h3>AI Recommendations</h3>
            </div>
            <img src={recommendations} alt="Personalized eyewear recommendations" />
            <div className="card-content">
              <p>Smart suggestions tailored just for you</p>
              <ul className="feature-list">
                <li>Based on user preferences</li>
                <li>Personalized from browsing history</li>
                <li>Previous interaction insights</li>
                <li>Style & fit recommendations</li>
              </ul>
              <button className="service-btn">Get Recommendations</button>
            </div>
          </div>

          {/* Online Vision Test Quiz */}
          <div className="service-card">
            <div className="card-header">
              <div className="card-icon">🔍</div>
              <h3>Vision Test Quiz</h3>
            </div>
            <img src={visionTest} alt="AI-assisted vision test" />
            <div className="card-content">
              <p>Preliminary self-check for your vision needs</p>
              <ul className="feature-list">
                <li>AI-assisted basic screening</li>
                <li>Preliminary vision self-check</li>
                <li>Helps decide if appointment needed</li>
                <li>Instant results & guidance</li>
              </ul>
              <button className="service-btn">Take Test</button>
            </div>
          </div>

          {/* AI Chatbot Support */}
          <div className="service-card">
            <div className="card-header">
              <div className="card-icon">💬</div>
              <h3>AI Chatbot Support</h3>
            </div>
            <img src={aiChatbot} alt="AI chatbot assistance" />
            <div className="card-content">
              <p>Instant answers and assistance anytime</p>
              <ul className="feature-list">
                <li>Answers frequently asked questions</li>
                <li>Assists with appointment booking</li>
                <li>Helps with product inquiries</li>
                <li>Provides clinic information</li>
                <li>24/7 instant responses</li>
              </ul>
              <button className="service-btn">Chat Now</button>
            </div>
          </div>

          {/* Notifications & Messaging */}
          <div className="service-card">
            <div className="card-header">
              <div className="card-icon">🔔</div>
              <h3>Notifications & Messaging</h3>
            </div>
            <img src={notifications} alt="Notification services" />
            <div className="card-content">
              <p>Stay informed with timely updates</p>
              <ul className="feature-list">
                <li>Email/SMS reminders</li>
                <li>Appointment status updates</li>
                <li>Product pickup notifications</li>
                <li>Chatbot inquiry responses</li>
                <li>Service updates</li>
              </ul>
              <button className="service-btn">Manage Preferences</button>
            </div>
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="process-section">
        <div className="section-header">
          <h2>How Our Digital Services Work</h2>
          <p>A seamless journey from discovery to care</p>
        </div>
        <div className="process-steps">
          <div className="process-step">
            <div className="step-number">1</div>
            <h4>Create Account</h4>
            <p>Set up your personal profile in minutes</p>
          </div>
          <div className="process-step">
            <div className="step-number">2</div>
            <h4>Take Vision Quiz</h4>
            <p>Complete our AI-assisted preliminary assessment</p>
          </div>
          <div className="process-step">
            <div className="step-number">3</div>
            <h4>Book Appointment</h4>
            <p>Schedule your visit at your convenience</p>
          </div>
          <div className="process-step">
            <div className="step-number">4</div>
            <h4>Receive Care</h4>
            <p>Experience premium optical services</p>
          </div>
        </div>
      </section>

      {/* CTA SECTION */}
      <section className="cta-section">
        <div className="cta-content">
          <h2>Ready to Experience Modern Eye Care?</h2>
          <p>Join thousands of satisfied patients who trust our digital-first approach to optical health.</p>
          <div className="cta-buttons">
            <button className="cta-btn primary">Create Account</button>
            <button className="cta-btn secondary">Book Appointment</button>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="services-footer">
        <div className="footer-content">
          <div className="footer-section">
            <h4>Doctor EC Optical Clinic</h4>
            <p>Where technology meets compassionate eye care</p>
          </div>
          <div className="footer-section">
            <h5>Digital Support</h5>
            <p>support@doctorec-optical.com</p>
            <p>+1 (555) 123-4567</p>
            <p>Live Chat Available</p>
          </div>
          <div className="footer-section">
            <h5>Connect With Us</h5>
            <div className="social-icons">
              <span>📱</span>
              <span>💼</span>
              <span>📸</span>
              <span>👔</span>
            </div>
          </div>
        </div>
        <div className="footer-bottom">
          <p>© 2025 Doctor EC Optical Clinic. All rights reserved.</p>
          <div className="footer-links">
            <a href="#privacy">Privacy Policy</a>
            <a href="#terms">Terms of Service</a>
            <a href="#accessibility">Accessibility</a>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default Services;