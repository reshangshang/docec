import React, { useState } from "react";
import "./ProductModal.css";
import InquiryFormModal from "./InquiryFormModal";

const ProductModal = ({ product, onClose }) => {
  const [showInquiry, setShowInquiry] = useState(false);

  if (!product) return null;

  return (
    <>
      <div className="modal-overlay" onClick={onClose}>
        <div
          className="modal-content"
          onClick={(e) => e.stopPropagation()}
        >
          <h2 className="modal-title">Product Details Form</h2>

          <div className="modal-body">
            <div className="modal-left">
              <img src={product.image} alt={product.name} />
              <div className="thumbnail-row">
                {[...Array(4)].map((_, i) => (
                  <img key={i} src={product.image} alt="thumbnail" />
                ))}
              </div>
            </div>

            <div className="modal-right">
              <h3>{product.name}</h3>
              <p className="price">{product.price}</p>

              <div className="specs">
                <p>
                  <strong>Specification:</strong> {product.specification}
                </p>
                <p>
                  <strong>Lens Size:</strong> {product.lensSize}
                </p>
                <p>
                  <strong>Material:</strong> {product.material}
                </p>
                <p>
                  <strong>Availability:</strong> {product.stock} Left
                </p>
              </div>

              <div className="modal-actions">
                <button
                  className="inquire-btn"
                  onClick={() => setShowInquiry(true)}
                >
                  Inquire
                </button>
                <button className="cancel-btn" onClick={onClose}>
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showInquiry && (
        <InquiryFormModal
          product={product}
          onClose={() => setShowInquiry(false)}
        />
      )}
    </>
  );
};

export default ProductModal;
