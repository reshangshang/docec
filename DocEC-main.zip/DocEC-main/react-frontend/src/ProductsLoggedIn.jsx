import React, { useState } from "react";
import "./ProductsLoggedIn.css";
import ProductModal from "./ProductModal";

import aviator from "./assets/sunglasses1.png";
import wayfarer from "./assets/sunglasses2.png";
import round from "./assets/sunglasses3.png";
import catEye from "./assets/sunglasses4.png";
import sport from "./assets/sunglasses5.png";
import kids from "./assets/sunglasses6.png";

const ProductsLoggedIn = () => {
  const [selectedProduct, setSelectedProduct] = useState(null);

  const products = [
    {
      id: 1,
      name: "Aviator Classic",
      price: "₱500.00",
      image: aviator,
      specification: "UV400 Protection, Polarized",
      lensSize: "58mm",
      material: "Metal Alloy Frame",
      stock: 24,
    },
    {
      id: 2,
      name: "Wayfarer Sunglasses",
      price: "₱650.00",
      image: wayfarer,
      specification: "UV400, Anti-Scratch Coating",
      lensSize: "55mm",
      material: "Acetate Frame",
      stock: 12,
    },
    {
      id: 3,
      name: "Round Sunglasses",
      price: "₱550.00",
      image: round,
      specification: "Double UV Filter, Light Tint",
      lensSize: "52mm",
      material: "Metal Frame with Soft Pads",
      stock: 15,
    },
    {
      id: 4,
      name: "Cat Eye Sunglasses",
      price: "₱700.00",
      image: catEye,
      specification: "UV400 Protection, Gradient Lens",
      lensSize: "54mm",
      material: "High-Grade Plastic Frame",
      stock: 9,
    },
    {
      id: 5,
      name: "Sport Sunglasses",
      price: "₱800.00",
      image: sport,
      specification: "Polarized, Anti-Glare, Windproof",
      lensSize: "60mm",
      material: "Polycarbonate Frame",
      stock: 18,
    },
    {
      id: 6,
      name: "Kids Sunglasses",
      price: "₱400.00",
      image: kids,
      specification: "UV400 Safe for Kids, Flexible Frame",
      lensSize: "48mm",
      material: "Soft Silicone Material",
      stock: 30,
    },
  ];

  return (
    <div className="products-container">
      {/* HEADER */}
      <section className="products-header">
        <div className="search-bar">
          <input type="text" placeholder="Search by product name or model" />
          <button className="search-btn">
            <i className="fas fa-search"></i>
          </button>
        </div>

        <div className="filter-sort">
          <button className="filter-btn">Filter</button>
          <button className="sort-btn">Sort By</button>
        </div>
      </section>

      {/* PRODUCT GRID */}
      <section className="products-section">
        <h2>Product Catalog</h2>
        <div className="product-grid">
          {products.map((product) => (
            <div className="product-card" key={product.id}>
              <div className="image-wrapper">
                <img src={product.image} alt={product.name} />
              </div>
              <div className="product-info">
                <h3>{product.name}</h3>
                <p>{product.price}</p>
                <button
                  className="order-btn"
                  onClick={() => setSelectedProduct(product)}
                >
                  Order
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <footer className="footer-section">
        © 2025 Doctor EC Optical Clinic. All rights reserved.
      </footer>

      {/* MODAL */}
      {selectedProduct && (
        <ProductModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
        />
      )}
    </div>
  );
};

export default ProductsLoggedIn;
