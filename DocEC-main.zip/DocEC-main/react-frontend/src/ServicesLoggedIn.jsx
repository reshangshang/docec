import React, { useState } from "react";
import "./ServicesLoggedIn.css";
import AppointmentModal from "../src/AppointmentModal"; // adjust path if needed
import clinicserv from "./assets/clinicserv.jpg";
import phoneser from "./assets/phoneser.jpg";
import videoser from "./assets/videoser.jpg";

const ServicesLoggedIn = () => {
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedService, setSelectedService] = useState("");

  const openModal = (service) => {
    setSelectedService(service);
    setModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
    setSelectedService("");
  };

  const handleSubmit = (formData) => {
    console.log("Booking submitted:", formData);
    alert(`Appointment booked for ${formData.service}`);
    closeModal();
  };

  return (
    <div className="services-container">
      {/* HERO SECTION */}
      <section className="services-hero">
        <h2>Our Services</h2>
      </section>

      {/* SERVICES GRID */}
      <div className="services-grid">
        <div className="service-card">
          <div className="service-icon">
            <img src={clinicserv} alt="In-Clinic Consultation" />
          </div>
          <div className="service-content">
            <h3>In-Clinic Consultation</h3>
            <p>Visit our clinic for a personalized, detailed check-up.</p>
            <button onClick={() => openModal("In-Clinic Consultation")}>
              Select
            </button>
          </div>
        </div>

        <div className="service-card">
          <div className="service-icon">
            <img src={phoneser} alt="Phone Consultation" />
          </div>
          <div className="service-content">
            <h3>Phone Consultation</h3>
            <p>Speak with our specialists through a convenient phone call.</p>
            <button onClick={() => openModal("Phone Consultation")}>
              Select
            </button>
          </div>
        </div>

        <div className="service-card">
          <div className="service-icon">
            <img src={videoser} alt="Online Consultation" />
          </div>
          <div className="service-content">
            <h3>Online Consultation</h3>
            <p>Consult our doctor via video call — anytime, anywhere.</p>
            <button onClick={() => openModal("Online Consultation")}>
              Select
            </button>
          </div>
        </div>
      </div>

      {/* MODAL */}
      <AppointmentModal
        open={modalOpen}
        onClose={closeModal}
        onSubmit={handleSubmit}
        initialService={selectedService}
      />

      {/* FOOTER */}
      <footer className="footer-section">
        © 2025 Your Clinic. All rights reserved.
      </footer>
    </div>
  );
};

export default ServicesLoggedIn;
