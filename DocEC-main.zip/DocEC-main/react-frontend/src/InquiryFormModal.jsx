import React, { useState } from "react";
import "./InquiryFormModal.css";

const InquiryFormModal = ({ product, onClose }) => {
  const [formData, setFormData] = useState({
    name: "",
    contact: "",
    message: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(
      `Inquiry submitted for ${product.name}!\n\nName: ${formData.name}\nContact: ${formData.contact}\nMessage: ${formData.message}`
    );
    onClose();
  };

  return (
    <div className="inquiry-overlay" onClick={onClose}>
      <div
        className="inquiry-modal"
        onClick={(e) => e.stopPropagation()} // prevent closing when clicking inside
      >
        <h3 className="inquiry-title">
          Product Inquiry for {product.name}
        </h3>

        <form onSubmit={handleSubmit} className="inquiry-form">
          <label>
            Name:
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            Contact Number:
            <input
              type="text"
              name="contact"
              value={formData.contact}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            Message/Question:
            <textarea
              name="message"
              value={formData.message}
              onChange={handleChange}
              required
            ></textarea>
          </label>

          <div className="inquiry-actions">
            <button type="submit" className="confirm-btn">
              Confirm
            </button>
            <button
              type="button"
              className="cancel-btn"
              onClick={onClose}
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default InquiryFormModal;
