import React from "react";
import "./HomeLoggedIn.css";

import heroDoctors from "./assets/hero-doctors.jpg";
import clinic from "./assets/clinic.jpg";

import prod1 from "./assets/prod1.jpg";
import prod2 from "./assets/prod2.jpg";
import prod3 from "./assets/prod3.jpg";
import prod4 from "./assets/prod4.jpg";
import prod5 from "./assets/prod5.jpg";
import prod6 from "./assets/prod6.jpg";
import prod7 from "./assets/prod7.jpg";
import prod8 from "./assets/prod8.jpg";
import prod9 from "./assets/prod9.jpg";
import prod10 from "./assets/prod10.jpg";

import category1 from "./assets/category1.jpg";
import category2 from "./assets/category2.jpg";
import category3 from "./assets/category3.jpg";

function HomeLoggedIn() {
  return (
    <div className="home-container">
      {/* HERO SECTION */}
      <section className="hero-section" id="home">
        <div className="hero-text">
          <h2>Doctor EC Optical Clinic</h2>
          <p>
            Discover a clearer, brighter world with Doc EC Optical Clinic.
            We bring together advanced technology, expert care, and a wide
            range of eyewear options to meet your vision needs.
          </p>
        </div>

        <div className="hero-img">
          <img src={heroDoctors} alt="Clinic Staff" />
        </div>
      </section>

      {/* SERVICES SECTION */}
      <section className="services-section" id="services">
        <div className="services-img">
          <img src={clinic} alt="Clinic Interior" />
        </div>
        <div className="services-text">
          <h3>Services and About Us</h3>
          <p>
            Doctor EC Optical Clinic provides quality and compassionate eye
            care for all ages. We offer comprehensive eye check-ups, vision
            testing, prescription eyeglasses and contact lenses, as well as
            disease screening and frame adjustments.
          </p>
          <p>
            With personalized care and professional service, we help you see
            clearly and protect your vision for the future.
          </p>
          <button className="read-btn">Read More...</button>
        </div>
      </section>

      {/* PRODUCTS SECTION */}
      <section className="products-section" id="products">
        <h3>Products</h3>

        <div className="product-grid">
          {[prod1, prod2, prod3, prod4, prod5, prod6, prod7, prod8, prod9, prod10].map(
            (product, index) => (
              <div className="product-card" key={index}>
                <img src={product} alt={`Product ${index + 1}`} />
              </div>
            )
          )}
        </div>
      </section>

      {/* BEST DEALS SECTION */}
      <section className="deals-section">
        <h3>Best Deals for Week</h3>
        <button className="order-btn">Order</button>
      </section>

      {/* CATEGORY SECTION */}
      <section className="category-section">
        <h3>Category</h3>

        <div className="category-grid">
          <div className="category-left">
            <img src={category1} alt="Category 1" />
          </div>

          <div className="category-right">
            <img src={category2} alt="Category 2" />
            <img src={category3} alt="Category 3" />
          </div>
        </div>
      </section>

      {/* FOOTER SECTION */}
      <footer className="footer-section">
        <p>© 2025 Doctor EC Optical Clinic. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default HomeLoggedIn;
