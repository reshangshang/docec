import React, { useState } from "react";
import "./SignInModal.css";
import logo from "./assets/logo.jpg";

function SignInModal({ onClose, onSignInSuccess }) {
  const [isRegister, setIsRegister] = useState(true);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    if (isRegister && password !== confirmPassword) {
      alert("Passwords do not match!");
      return;
    }

    // 👇 Create user data object
    const userData = {
      name: isRegister ? name : "User", // If login, fallback to generic name
      email: email,
      age: 25, // You can later replace this with an input field or fetched data
      gender: "Not specified",
      phone: "N/A",
    };

    // 👇 Pass user data to parent
    onSignInSuccess(userData);
  };

  return (
    <div className="modal-overlay">
      <div className="auth-box">
        <button className="close-btn" onClick={onClose}>✕</button>

        <div className="auth-content">
          {/* LEFT SIDE */}
          <div className="auth-left">
            <img src={logo} alt="Clinic Logo" className="auth-logo" />
            <h1>Doctor EC Optical Clinic</h1>
            <p>Your Vision, Our Focus.</p>
          </div>

          {/* RIGHT SIDE */}
          <div className="auth-right">
            <h2>{isRegister ? "Create an Account" : "Welcome Back!"}</h2>
            <form onSubmit={handleSubmit}>
              {isRegister && (
                <input
                  type="text"
                  placeholder="Full Name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              )}
              <input
                type="email"
                placeholder="Email Address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
              {isRegister && (
                <input
                  type="password"
                  placeholder="Confirm Password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                />
              )}
              <button type="submit" className="login-btn">
                {isRegister ? "Register" : "Login"}
              </button>
            </form>

            <p className="switch-mode">
              {isRegister ? (
                <>
                  Already have an account?{" "}
                  <span onClick={() => setIsRegister(false)}>Login</span>
                </>
              ) : (
                <>
                  Don’t have an account?{" "}
                  <span onClick={() => setIsRegister(true)}>Register</span>
                </>
              )}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default SignInModal;
