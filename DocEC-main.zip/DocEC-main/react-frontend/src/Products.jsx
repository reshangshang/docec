// Products.jsx
import React, { useState } from "react";
import "./Products.css";

// Import product images (you'll need to add these to your assets folder)
import prod1 from "./assets/prod1.jpg";
import prod2 from "./assets/prod2.jpg";
import prod3 from "./assets/prod3.jpg";
import prod4 from "./assets/prod4.jpg";
import prod5 from "./assets/prod5.jpg";
import prod6 from "./assets/prod6.jpg";
import prod7 from "./assets/prod7.jpg";
import prod8 from "./assets/prod8.jpg";
import prod9 from "./assets/prod9.jpg";
import prod10 from "./assets/prod10.jpg";

function Products() {
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedBrand, setSelectedBrand] = useState("");
  const [selectedType, setSelectedType] = useState("");
  const [searchQuery, setSearchQuery] = useState("");

  const products = [
    { id: 1, image: prod1, name: "Classic Aviator", price: 149, category: "eyeglasses", brand: "rayban", type: "men" },
    { id: 2, image: prod2, name: "Vintage Round", price: 129, category: "eyeglasses", brand: "gucci", type: "women" },
    { id: 3, image: prod3, name: "Modern Square", price: 159, category: "eyeglasses", brand: "oakley", type: "men" },
    { id: 4, image: prod4, name: "Cat Eye Frames", price: 139, category: "eyeglasses", brand: "gucci", type: "women" },
    { id: 5, image: prod5, name: "Rectangle Frames", price: 119, category: "contacts", brand: "rayban", type: "men" },
    { id: 6, image: prod6, name: "Oval Glasses", price: 99, category: "contacts", brand: "oakley", type: "women" },
    { id: 7, image: prod7, name: "Sport Wraparound", price: 179, category: "accessories", brand: "rayban", type: "men" },
    { id: 8, image: prod8, name: "Designer Frames", price: 199, category: "eyeglasses", brand: "gucci", type: "women" },
    { id: 9, image: prod9, name: "Minimalist Metal", price: 89, category: "accessories", brand: "oakley", type: "men" },
    { id: 10, image: prod10, name: "Bold Acetate", price: 139, category: "eyeglasses", brand: "rayban", type: "women" },
  ];

  const filteredProducts = products.filter(product => {
    const matchesCategory = !selectedCategory || product.category === selectedCategory;
    const matchesBrand = !selectedBrand || product.brand === selectedBrand;
    const matchesType = !selectedType || product.type === selectedType;
    const matchesSearch = !searchQuery || product.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesMinPrice = !minPrice || product.price >= parseInt(minPrice);
    const matchesMaxPrice = !maxPrice || product.price <= parseInt(maxPrice);
    
    return matchesCategory && matchesBrand && matchesType && matchesSearch && matchesMinPrice && matchesMaxPrice;
  });

  const clearFilters = () => {
    setSelectedCategory("");
    setSelectedBrand("");
    setSelectedType("");
    setSearchQuery("");
    setMinPrice("");
    setMaxPrice("");
  };

  return (
    <div className="products-container">
      {/* HERO SECTION */}
      <section className="products-hero">
        <div className="hero-overlay">
          <div className="products-hero-content">
            <h1>Discover Perfect Vision & Style</h1>
            <p>
              Explore our premium collection of eyewear designed to enhance your vision 
              while complementing your unique personality and lifestyle.
            </p>
          </div>
        </div>
      </section>

      {/* MAIN CONTENT WITH SIDEBAR LAYOUT */}
      <div className="main-content-wrapper">
        {/* SIDEBAR FILTERS */}
        <aside className="sidebar-filters">
          <div className="filters-header">
            <h3>Filters</h3>
            <button className="clear-filters-btn" onClick={clearFilters}>
              Clear All
            </button>
          </div>

          <div className="filter-section">
            <h4 className="filter-title">Search Products</h4>
            <div className="search-container">
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="search-input"
              />
              <span className="search-icon">🔍</span>
            </div>
          </div>

          <div className="filter-section">
            <h4 className="filter-title">Category</h4>
            <div className="filter-select-wrapper">
              <select 
                className="filter-select"
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
              >
                <option value="">All Categories</option>
                <option value="eyeglasses">Eyeglasses</option>
                <option value="contacts">Contact Lenses</option>
                <option value="accessories">Accessories</option>
              </select>
              <span className="dropdown-arrow">▼</span>
            </div>
          </div>

          <div className="filter-section">
            <h4 className="filter-title">Brand</h4>
            <div className="filter-select-wrapper">
              <select 
                className="filter-select"
                value={selectedBrand}
                onChange={(e) => setSelectedBrand(e.target.value)}
              >
                <option value="">All Brands</option>
                <option value="rayban">Ray-Ban</option>
                <option value="oakley">Oakley</option>
                <option value="gucci">Gucci</option>
              </select>
              <span className="dropdown-arrow">▼</span>
            </div>
          </div>

          <div className="filter-section">
            <h4 className="filter-title">Type</h4>
            <div className="filter-select-wrapper">
              <select 
                className="filter-select"
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
              >
                <option value="">All Types</option>
                <option value="men">Men</option>
                <option value="women">Women</option>
                <option value="kids">Kids</option>
              </select>
              <span className="dropdown-arrow">▼</span>
            </div>
          </div>

          <div className="filter-section">
            <h4 className="filter-title">Price Range</h4>
            <div className="price-inputs">
              <div className="price-input-group">
                <input
                  type="number"
                  placeholder="Min"
                  value={minPrice}
                  onChange={(e) => setMinPrice(e.target.value)}
                  className="price-input"
                />
              </div>
              <span className="price-separator">—</span>
              <div className="price-input-group">
                <input
                  type="number"
                  placeholder="Max"
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(e.target.value)}
                  className="price-input"
                />
              </div>
            </div>
          </div>
        </aside>

        {/* PRODUCTS GRID */}
        <main className="products-main">
          <div className="section-header">
            <div className="header-content">
              <h2>Our Collection</h2>
              <p className="section-subtitle">Handcrafted eyewear for every vision need</p>
            </div>
            <div className="results-info">
              <span className="results-count">{filteredProducts.length} products</span>
              <div className="sort-select-wrapper">
                <select className="sort-select">
                  <option>Sort by: Featured</option>
                  <option>Price: Low to High</option>
                  <option>Price: High to Low</option>
                  <option>Newest Arrivals</option>
                </select>
                <span className="dropdown-arrow">▼</span>
              </div>
            </div>
          </div>

          {filteredProducts.length === 0 ? (
            <div className="no-products">
              <div className="no-products-icon">👓</div>
              <h3>No products found</h3>
              <p>Try adjusting your filters or search terms</p>
              <button className="reset-filters-btn" onClick={clearFilters}>
                Reset All Filters
              </button>
            </div>
          ) : (
            <div className="products-grid">
              {filteredProducts.map((product) => (
                <div key={product.id} className="product-card">
                  <div className="product-image-container">
                    <img src={product.image} alt={product.name} className="product-image" />
                    <div className="product-overlay">
                      <div className="product-actions">
                        <button className="view-details-btn">View Details</button>
                        <button className="add-to-cart-overlay-btn">Add to Cart</button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </main>
      </div>

      {/* CTA SECTION */}
      <section className="cta-section">
        <div className="cta-content">
          <h3>Need Help Choosing?</h3>
          <p>Our optical experts are here to help you find the perfect fit</p>
          <div className="cta-buttons">
            <button className="cta-btn primary">Book Consultation</button>
            <button className="cta-btn secondary">Virtual Try-On</button>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="footer-section">
        <div className="footer-content">
          <p>© 2025 Doctor EC Optical Clinic. All Rights Reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default Products;