import React from "react";
import "./UserProfile.css";

const UserProfile = ({ user, onClose, onExplicitSignOut }) => {
  return (
    <div className="profile-card">
      <div className="profile-header">
        <div className="profile-icon">
          {user.name
            .split(" ")
            .map((n) => n[0])
            .join("")}
        </div>
        <div>
          <h2>{user.name}</h2>
          <p>🎂 {user.age} years old</p>
        </div>
      </div>
      <hr />
      <div className="profile-info">
        <p><strong>Gender:</strong> {user.gender}</p>
        <p><strong>Email:</strong> {user.email}</p>
        <p><strong>Phone:</strong> {user.phone}</p>
      </div>
      <div className="profile-actions">
        <button className="btn" onClick={onExplicitSignOut}>Sign Out</button>
        <button className="btn outline" onClick={onClose}>Close</button>
      </div>
    </div>
  );
};

export default UserProfile;
