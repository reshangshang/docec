// AboutUs.jsx
import React from "react";
import "./AboutUs.css";

import docabout from "./assets/docabout.png";
import abouteye from "./assets/abouteye.png";
import opteme from "./assets/opteme.png";
import recep from "./assets/recep.png";
import sales from "./assets/sales.png";
import clean from "./assets/clean.png";
import loc from "./assets/loc.png";
import systemDashboard from "./assets/dashboard.jpg";
import teamPhoto from "./assets/team-photo.jpg";

const AboutUs = () => {
  return (
    <div className="about-container">
      {/* HERO SECTION */}
      <section className="about-hero">
        <div className="hero-background">
          <div className="soft-shape shape-1"></div>
          <div className="soft-shape shape-2"></div>
        </div>
        <div className="hero-content">
          <div className="hero-text">
            <h1>About DOC-OptiSys</h1>
            <p className="hero-subtitle">
              AI-Enhanced Web-Based Optical Clinic Management System
            </p>
            <p>
              Transforming traditional optical care through intelligent digital solutions 
              that enhance patient experience and streamline clinic operations.
            </p>
          </div>
          <div className="hero-image">
            <img src={systemDashboard} alt="DOC-OptiSys Dashboard" />
          </div>
        </div>
      </section>

      {/* INTRODUCTION SECTION */}
      <section className="intro-section">
        <div className="section-container">
          <div className="section-header">
            <h2>Welcome to Doctor EC Optical Clinic</h2>
            <p>Where Tradition Meets Innovation</p>
          </div>
          <div className="intro-content">
            <div className="intro-text">
              <p>
                At Doctor EC Optical Clinic, we've embraced the digital transformation 
                in healthcare by developing <strong>DOC-OptiSys</strong> - an intelligent 
                web-based platform that revolutionizes how patients access optical care 
                and how clinics manage their operations.
              </p>
              <p>
                Our journey began with a simple observation: traditional manual processes 
                were creating barriers to quality eye care. Long waiting times, scheduling 
                conflicts, and limited product visibility were challenges we knew we could 
                solve with technology.
              </p>
              <p>
                DOC-OptiSys represents our commitment to bridging the gap between 
                traditional optical services and modern digital convenience, ensuring 
                every patient receives the care they deserve with the efficiency they expect.
              </p>
            </div>
            <div className="intro-stats">
              <div className="stat-item">
                <div className="stat-number">50%</div>
                <div className="stat-label">Reduction in Scheduling Conflicts</div>
              </div>
              <div className="stat-item">
                <div className="stat-number">40%</div>
                <div className="stat-label">Increase in Appointment Utilization</div>
              </div>
              <div className="stat-item">
                <div className="stat-number">85%</div>
                <div className="stat-label">AI Feedback Accuracy</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* MISSION & VISION */}
      <section className="mission-section">
        <div className="section-container">
          <div className="mission-cards">
            <div className="mission-card">
              <div className="card-icon">🎯</div>
              <h3>Our Mission</h3>
              <p>
                To provide accessible, efficient, and intelligent optical care services 
                that enhance patient experience through automation and AI-enhanced tools, 
                while modernizing clinic workflow and reducing manual workload.
              </p>
            </div>
            <div className="mission-card">
              <div className="card-icon">🔭</div>
              <h3>Our Vision</h3>
              <p>
                To be the leading innovator in optical care technology, setting new 
                standards for patient convenience, operational efficiency, and intelligent 
                healthcare solutions through continuous technological advancement.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CORE SERVICES */}
      <section className="services-section">
        <div className="section-container">
          <div className="section-header">
            <h2>What DOC-OptiSys Offers</h2>
            <p>Comprehensive Digital Solutions for Modern Optical Care</p>
          </div>
          <div className="services-grid">
            <div className="service-card">
              <div className="service-icon">📅</div>
              <h4>Online Appointment Booking</h4>
              <p>
                Smart scheduling with real-time availability, automated reminders, 
                and AI-powered no-show prediction to optimize clinic efficiency.
              </p>
            </div>

            <div className="service-card">
              <div className="service-icon">🛍️</div>
              <h4>Online Product Catalog</h4>
              <p>
                Interactive browsing of eyewear, frames, lenses, and accessories 
                with detailed descriptions and high-quality visuals.
              </p>
            </div>

            <div className="service-card">
              <div className="service-icon">🤖</div>
              <h4>AI Recommendations</h4>
              <p>
                Personalized eyewear suggestions based on user preferences, 
                browsing history, and prescription data for tailored experiences.
              </p>
            </div>

            <div className="service-card">
              <div className="service-icon">📊</div>
              <h4>Inventory Management</h4>
              <p>
                Real-time stock updates, automated low-stock alerts, and 
                AI-driven demand forecasting for optimal inventory control.
              </p>
            </div>

            <div className="service-card">
              <div className="service-icon">💬</div>
              <h4>AI Chatbot Support</h4>
              <p>
                24/7 automated assistance for patient inquiries, booking help, 
                and product support with natural language processing.
              </p>
            </div>

            <div className="service-card">
              <div className="service-icon">📈</div>
              <h4>Feedback Analytics</h4>
              <p>
                AI-powered sentiment analysis of user reviews to identify 
                service improvements and enhance patient satisfaction.
              </p>
            </div>

            <div className="service-card">
              <div className="service-icon">🔍</div>
              <h4>Vision Test Quiz</h4>
              <p>
                Basic AI-assisted self-assessment tool for preliminary vision 
                screening before scheduling professional consultations.
              </p>
            </div>

            <div className="service-card">
              <div className="service-icon">⚡</div>
              <h4>Smart Reporting</h4>
              <p>
                Comprehensive analytics and reporting tools for appointment 
                tracking, product performance, and operational insights.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* INNOVATION COMMITMENT */}
      <section className="innovation-section">
        <div className="section-container">
          <div className="innovation-content">
            <div className="innovation-text">
              <h2>Commitment to Innovation</h2>
              <p>
                At the heart of DOC-OptiSys lies our dedication to leveraging cutting-edge 
                technology for better healthcare outcomes. Our platform integrates advanced 
                AI and machine learning capabilities that continuously learn and adapt to 
                improve patient experiences.
              </p>
              <div className="innovation-features">
                <div className="feature">
                  <span className="checkmark">✓</span>
                  <span>Predictive scheduling algorithms</span>
                </div>
                <div className="feature">
                  <span className="checkmark">✓</span>
                  <span>Intelligent product forecasting</span>
                </div>
                <div className="feature">
                  <span className="checkmark">✓</span>
                  <span>Natural language processing for chatbot</span>
                </div>
                <div className="feature">
                  <span className="checkmark">✓</span>
                  <span>Data-driven operational insights</span>
                </div>
              </div>
            </div>
            <div className="innovation-image">
              <img src={abouteye} alt="Innovation in Eye Care" />
            </div>
          </div>
        </div>
      </section>

      {/* TRUST FACTORS */}
      <section className="trust-section">
        <div className="section-container">
          <div className="section-header">
            <h2>Why Patients Trust Us</h2>
            <p>Building Confidence Through Technology and Care</p>
          </div>
          <div className="trust-grid">
            <div className="trust-card">
              <div className="trust-icon">⏱️</div>
              <h4>Reduced Waiting Times</h4>
              <p>Smart scheduling minimizes delays and optimizes appointment flow</p>
            </div>
            <div className="trust-card">
              <div className="trust-icon">🔒</div>
              <h4>Secure Data Handling</h4>
              <p>Enterprise-grade security protecting all patient information</p>
            </div>
            <div className="trust-card">
              <div className="trust-icon">📱</div>
              <h4>Modern Accessibility</h4>
              <p>Web-based platform accessible from any device, anywhere</p>
            </div>
            <div className="trust-card">
              <div className="trust-icon">💬</div>
              <h4>Clear Communication</h4>
              <p>Real-time notifications and updates for all interactions</p>
            </div>
            <div className="trust-card">
              <div className="trust-icon">🎯</div>
              <h4>Personalized Care</h4>
              <p>AI-driven recommendations tailored to individual needs</p>
            </div>
            <div className="trust-card">
              <div className="trust-icon">⚡</div>
              <h4>Operational Efficiency</h4>
              <p>Streamlined processes that benefit both patients and staff</p>
            </div>
          </div>
        </div>
      </section>

      {/* TEAM SECTION */}
      <section className="team-section">
        <div className="section-container">
          <div className="section-header">
            <h2>About The Team</h2>
            <p>Passionate Developers Behind DOC-OptiSys</p>
          </div>
          <div className="team-content">
            <div className="team-image">
              <img src={teamPhoto} alt="Development Team" />
            </div>
            <div className="team-info">
              <h3>Built with Excellence</h3>
              <p>
                DOC-OptiSys was developed by dedicated BSIT students from Mindoro State University, 
                College of Computer Studies, as a capstone project that addresses real-world 
                challenges in optical clinic management.
              </p>
              <p>
                Our team combined academic knowledge with practical problem-solving to create 
                a system that not only meets current needs but also anticipates future demands 
                in digital healthcare.
              </p>
              <div className="team-features">
                <div className="team-feature">
                  <strong>Jesserene Espinosa</strong>
                  <span>Project Lead & Developer</span>
                </div>
                <div className="team-feature">
                  <strong>Charity Gonzaga</strong>
                  <span>Backend & Database Specialist</span>
                </div>
                <div className="team-feature">
                  <strong>Cecille Ariane Dela Peña</strong>
                  <span>Frontend & UI/UX Developer</span>
                </div>
                <div className="team-feature">
                  <strong>Reshallyn Mortel</strong>
                  <span>AI Integration & Testing</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA SECTION */}
      <section className="cta-section">
        <div className="section-container">
          <div className="cta-content">
            <h2>Experience the Future of Optical Care</h2>
            <p>Join hundreds of satisfied patients who trust DOC-OptiSys for their eye care needs</p>
            <div className="cta-buttons">
              <button className="cta-btn primary">Book an Appointment</button>
              <button className="cta-btn secondary">Explore Services</button>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="footer-section">
        <div className="section-container">
          <p>© 2025 Doctor EC Optical Clinic. DOC-OptiSys - All Rights Reserved.</p>
          <p>Mindoro State University - College of Computer Studies</p>
        </div>
      </footer>
    </div>
  );
};

export default AboutUs;