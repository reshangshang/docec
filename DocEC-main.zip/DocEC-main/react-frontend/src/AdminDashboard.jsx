// AdminDashboard.jsx
import React, { useState } from "react";
import "./AdminDashboard.css";

import dashboardIcon from "./assets/dashboard.png";
import appointmentsIcon from "./assets/appointment.png";
import patientsIcon from "./assets/patients.png";
import productsIcon from "./assets/products.png";
import inventoryIcon from "./assets/inventory.png";
import chatbotIcon from "./assets/chatbot.png";
import reportsIcon from "./assets/reports.png";
import settingsIcon from "./assets/settings.png";
import adminProfile from "./assets/admin-profile.png";

function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(true);

  // Sample data - in real app, this would come from API
  const dashboardStats = {
    totalAppointments: 156,
    pendingAppointments: 12,
    completedAppointments: 134,
    totalPatients: 289,
    lowStockItems: 8,
    totalRevenue: "₱245,680"
  };

  const recentAppointments = [
    { id: 1, patient: "Maria Santos", date: "2025-01-15", time: "10:00 AM", type: "Eye Check-up", status: "confirmed" },
    { id: 2, patient: "Juan Dela Cruz", date: "2025-01-15", time: "11:30 AM", type: "Contact Lens Fitting", status: "pending" },
    { id: 3, patient: "Ana Reyes", date: "2025-01-15", time: "2:00 PM", type: "Frame Adjustment", status: "confirmed" },
    { id: 4, patient: "Carlos Lopez", date: "2025-01-16", time: "9:00 AM", type: "Comprehensive Exam", status: "pending" }
  ];

  const lowStockProducts = [
    { id: 1, name: "Ray-Ban Aviator", category: "Sunglasses", stock: 3, threshold: 5 },
    { id: 2, name: "Acuvue Oasys", category: "Contact Lenses", stock: 2, threshold: 10 },
    { id: 3, name: "Oakley Frame", category: "Frames", stock: 4, threshold: 6 }
  ];

  const renderDashboard = () => (
    <div className="dashboard-content">
      {/* Statistics Cards */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon">📅</div>
          <div className="stat-info">
            <h3>{dashboardStats.totalAppointments}</h3>
            <p>Total Appointments</p>
          </div>
          <div className="stat-trend positive">+12%</div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon">👥</div>
          <div className="stat-info">
            <h3>{dashboardStats.totalPatients}</h3>
            <p>Registered Patients</p>
          </div>
          <div className="stat-trend positive">+8%</div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon">⚠️</div>
          <div className="stat-info">
            <h3>{dashboardStats.pendingAppointments}</h3>
            <p>Pending Confirmations</p>
          </div>
          <div className="stat-trend warning">-5%</div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon">📦</div>
          <div className="stat-info">
            <h3>{dashboardStats.lowStockItems}</h3>
            <p>Low Stock Items</p>
          </div>
          <div className="stat-trend negative">+3</div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon">💰</div>
          <div className="stat-info">
            <h3>{dashboardStats.totalRevenue}</h3>
            <p>Total Revenue</p>
          </div>
          <div className="stat-trend positive">+15%</div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon">✅</div>
          <div className="stat-info">
            <h3>{dashboardStats.completedAppointments}</h3>
            <p>Completed Services</p>
          </div>
          <div className="stat-trend positive">+20%</div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="content-grid">
        {/* Recent Appointments */}
        <div className="content-card">
          <div className="card-header">
            <h3>Recent Appointments</h3>
            <button className="btn-view-all">View All</button>
          </div>
          <div className="appointments-list">
            {recentAppointments.map(appointment => (
              <div key={appointment.id} className="appointment-item">
                <div className="appointment-info">
                  <h4>{appointment.patient}</h4>
                  <p>{appointment.date} • {appointment.time}</p>
                  <span className="appointment-type">{appointment.type}</span>
                </div>
                <div className={`status-badge ${appointment.status}`}>
                  {appointment.status}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Low Stock Alert */}
        <div className="content-card">
          <div className="card-header">
            <h3>Low Stock Alert</h3>
            <button className="btn-view-all">Manage Inventory</button>
          </div>
          <div className="inventory-list">
            {lowStockProducts.map(product => (
              <div key={product.id} className="inventory-item">
                <div className="product-info">
                  <h4>{product.name}</h4>
                  <p>{product.category}</p>
                </div>
                <div className="stock-info">
                  <span className={`stock-level ${product.stock < product.threshold ? 'critical' : 'low'}`}>
                    {product.stock} left
                  </span>
                  <button className="btn-restock">Restock</button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* AI Insights */}
        <div className="content-card">
          <div className="card-header">
            <h3>AI Insights</h3>
            <span className="ai-badge">Powered by AI</span>
          </div>
          <div className="ai-insights">
            <div className="insight-item">
              <div className="insight-icon">📊</div>
              <div className="insight-content">
                <h4>No-Show Prediction</h4>
                <p>High probability for 3 appointments tomorrow</p>
                <span className="insight-accuracy">87% accuracy</span>
              </div>
            </div>
            <div className="insight-item">
              <div className="insight-icon">🎯</div>
              <div className="insight-content">
                <h4>Product Recommendations</h4>
                <p>Ray-Ban collections trending this week</p>
                <span className="insight-accuracy">92% match rate</span>
              </div>
            </div>
            <div className="insight-item">
              <div className="insight-icon">😊</div>
              <div className="insight-content">
                <h4>Sentiment Analysis</h4>
                <p>Positive feedback increased by 15% this month</p>
                <span className="insight-accuracy">85% accuracy</span>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="content-card">
          <div className="card-header">
            <h3>Quick Actions</h3>
          </div>
          <div className="quick-actions">
            <button className="quick-action-btn">
              <span className="action-icon">➕</span>
              Add New Product
            </button>
            <button className="quick-action-btn">
              <span className="action-icon">📅</span>
              Schedule Appointment
            </button>
            <button className="quick-action-btn">
              <span className="action-icon">📋</span>
              Generate Report
            </button>
            <button className="quick-action-btn">
              <span className="action-icon">🤖</span>
              Chatbot Settings
            </button>
            <button className="quick-action-btn">
              <span className="action-icon">📦</span>
              Update Inventory
            </button>
            <button className="quick-action-btn">
              <span className="action-icon">👥</span>
              Patient Management
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderAppointments = () => (
    <div className="tab-content">
      <h2>Appointment Management</h2>
      <p>Manage and track all patient appointments</p>
      {/* Appointment management content */}
    </div>
  );

  const renderPatients = () => (
    <div className="tab-content">
      <h2>Patient Management</h2>
      <p>View and manage patient records and history</p>
      {/* Patient management content */}
    </div>
  );

  const renderContent = () => {
    switch (activeTab) {
      case "dashboard": return renderDashboard();
      case "appointments": return renderAppointments();
      case "patients": return renderPatients();
      default: return renderDashboard();
    }
  };

  return (
    <div className="admin-dashboard">
      {/* Sidebar */}
      <div className={`sidebar ${sidebarOpen ? 'open' : 'closed'}`}>
        <div className="sidebar-header">
          <h2>DOC-OptiSys</h2>
          <span className="admin-role">Administrator</span>
        </div>
        
        <nav className="sidebar-nav">
          <button 
            className={`nav-item ${activeTab === 'dashboard' ? 'active' : ''}`}
            onClick={() => setActiveTab('dashboard')}
          >
            <span className="nav-icon">📊</span>
            <span className="nav-text">Dashboard</span>
          </button>
          
          <button 
            className={`nav-item ${activeTab === 'appointments' ? 'active' : ''}`}
            onClick={() => setActiveTab('appointments')}
          >
            <span className="nav-icon">📅</span>
            <span className="nav-text">Appointments</span>
          </button>
          
          <button 
            className={`nav-item ${activeTab === 'patients' ? 'active' : ''}`}
            onClick={() => setActiveTab('patients')}
          >
            <span className="nav-icon">👥</span>
            <span className="nav-text">Patients</span>
          </button>
          
          <button 
            className={`nav-item ${activeTab === 'products' ? 'active' : ''}`}
            onClick={() => setActiveTab('products')}
          >
            <span className="nav-icon">🛍️</span>
            <span className="nav-text">Products</span>
          </button>
          
          <button 
            className={`nav-item ${activeTab === 'inventory' ? 'active' : ''}`}
            onClick={() => setActiveTab('inventory')}
          >
            <span className="nav-icon">📦</span>
            <span className="nav-text">Inventory</span>
          </button>
          
          <button 
            className={`nav-item ${activeTab === 'chatbot' ? 'active' : ''}`}
            onClick={() => setActiveTab('chatbot')}
          >
            <span className="nav-icon">🤖</span>
            <span className="nav-text">AI Chatbot</span>
          </button>
          
          <button 
            className={`nav-item ${activeTab === 'reports' ? 'active' : ''}`}
            onClick={() => setActiveTab('reports')}
          >
            <span className="nav-icon">📋</span>
            <span className="nav-text">Reports & Analytics</span>
          </button>
          
          <button 
            className={`nav-item ${activeTab === 'settings' ? 'active' : ''}`}
            onClick={() => setActiveTab('settings')}
          >
            <span className="nav-icon">⚙️</span>
            <span className="nav-text">System Settings</span>
          </button>
        </nav>
        
        <div className="sidebar-footer">
          <div className="admin-profile">
            <img src={adminProfile} alt="Admin" className="profile-pic" />
            <div className="profile-info">
              <h4>Dr. Eleanor Cruz</h4>
              <p>Head Optometrist</p>
            </div>
          </div>
          <button className="logout-btn">🚪 Logout</button>
        </div>
      </div>

      {/* Main Content */}
      <div className="main-content">
        <header className="top-header">
          <div className="header-left">
            <button 
              className="menu-toggle"
              onClick={() => setSidebarOpen(!sidebarOpen)}
            >
              ☰
            </button>
            <h1>Admin Dashboard</h1>
          </div>
          <div className="header-right">
            <div className="header-actions">
              <button className="notification-btn">🔔</button>
              <button className="search-btn">🔍</button>
              <div className="user-menu">
                <span>Dr. Eleanor Cruz</span>
                <div className="user-avatar">EC</div>
              </div>
            </div>
          </div>
        </header>

        <div className="content-area">
          {renderContent()}
        </div>
      </div>
    </div>
  );
}

export default AdminDashboard;